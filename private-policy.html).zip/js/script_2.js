
            SmoothScroll({
                frameRate: 150,
                animationTime: 800,
                stepSize: 120,
                pulseAlgorithm: 1,
                pulseScale: 4,
                pulseNormalize: 1,
                accelerationDelta: 300,
                accelerationMax: 2,
                keyboardSupport: 1,
                arrowScroll: 50,
                fixedBackground: 0
            });
            